# راهنمای خیلی ساده ساخت APK

1. فایل‌های این پروژه را داخل ریشه repository گیت‌هاب قرار بده.
2. در GitHub وارد تب **Actions** شو.
3. روی workflow با نام **Build APK** بزن.
4. روی **Run workflow** بزن و دوباره **Run workflow** را تأیید کن.
5. صبر کن تا کار سبز و موفق شود.
6. وارد اجرای موفق workflow شو و از بخش **Artifacts** فایل `AIChatApp-Glass-v6-debug` را بگیر.
7. فایل ZIP دانلودشده را باز کن؛ داخل آن `app-debug.apk` است.

این APK برای نصب آزمایشی روی گوشی مناسب است. برای انتشار در Google Play باید نسخه Release و کلید امضای دائمی ساخته شود.

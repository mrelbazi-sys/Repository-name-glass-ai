package com.ehsan.aiglass

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import coil.compose.AsyncImage
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class Msg(val role:String, val text:String, val imageUri:String?=null)
data class SavedChat(val title:String, val messages:List<Msg>)

private val Navy=Color(0xFF06152F)
private val Glass=Color(0xFF12366A).copy(alpha=.55f)
private val Cyan=Color(0xFF26D9FF)
private val Blue=Color(0xFF248BFF)

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent{ GlassApp() }
    }
}

class LocalStore(context:Context){
    private val p=context.getSharedPreferences("ai_glass_v5",Context.MODE_PRIVATE)
    fun name()=p.getString("name","Ehsan").orEmpty()
    fun bio()=p.getString("bio","کاربر عادی").orEmpty()
    fun dark()=p.getBoolean("dark",true)
    fun saveProfile(n:String,b:String){p.edit().putString("name",n).putString("bio",b).apply()}
    fun saveDark(v:Boolean){p.edit().putBoolean("dark",v).apply()}
    fun saveHistory(list:List<SavedChat>){
        val a=JSONArray()
        list.take(30).forEach{h->
            val o=JSONObject().put("title",h.title)
            val m=JSONArray()
            h.messages.forEach{x->m.put(JSONObject().put("role",x.role).put("text",x.text).put("image",x.imageUri ?: ""))}
            o.put("messages",m);a.put(o)
        }
        p.edit().putString("history",a.toString()).apply()
    }
    fun loadHistory():List<SavedChat>{
        val out=mutableListOf<SavedChat>()
        val a=JSONArray(p.getString("history","[]") ?: "[]")
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i); val arr=o.getJSONArray("messages"); val msgs=mutableListOf<Msg>()
            for(j in 0 until arr.length()){
                val x=arr.getJSONObject(j)
                msgs.add(Msg(x.getString("role"),x.getString("text"),x.optString("image").ifBlank{null}))
            }
            out.add(SavedChat(o.getString("title"),msgs))
        }
        return out
    }
}


private data class Feature(val id:Int,val group:String,val title:String,val active:Boolean)
private val FEATURES_200=listOf(
Feature(1,"هوش مصنوعی و پاسخ","حالت پاسخ کوتاه/استاندارد/عمیق",true),
Feature(2,"هوش مصنوعی و پاسخ","پرامپت سیستمی قابل تنظیم",true),
Feature(3,"هوش مصنوعی و پاسخ","دستورهای آماده برای نویسندگی",true),
Feature(4,"هوش مصنوعی و پاسخ","بازنویسی پاسخ با یک لمس",true),
Feature(5,"هوش مصنوعی و پاسخ","خلاصه‌سازی پاسخ",true),
Feature(6,"هوش مصنوعی و پاسخ","ادامه پاسخ",true),
Feature(7,"هوش مصنوعی و پاسخ","تغییر لحن پاسخ",true),
Feature(8,"هوش مصنوعی و پاسخ","تغییر زبان پاسخ",true),
Feature(9,"هوش مصنوعی و پاسخ","پاسخ ساختاریافته با تیتر",true),
Feature(10,"هوش مصنوعی و پاسخ","پشتیبانی بهتر از Markdown",true),
Feature(11,"هوش مصنوعی و پاسخ","نمایش کد با قالب‌بندی",true),
Feature(12,"هوش مصنوعی و پاسخ","کپی بخشی از پاسخ",true),
Feature(13,"هوش مصنوعی و پاسخ","بازسازی پاسخ",true),
Feature(14,"هوش مصنوعی و پاسخ","ویرایش پیام کاربر",true),
Feature(15,"هوش مصنوعی و پاسخ","پاسخ به یک پیام مشخص",true),
Feature(16,"هوش مصنوعی و پاسخ","پین کردن پیام مهم",true),
Feature(17,"هوش مصنوعی و پاسخ","علامت‌گذاری مفید/نامفید",true),
Feature(18,"هوش مصنوعی و پاسخ","ذخیره پاسخ منتخب",true),
Feature(19,"هوش مصنوعی و پاسخ","جست‌وجوی داخل گفتگو",true),
Feature(20,"هوش مصنوعی و پاسخ","تعداد کاراکتر پاسخ",true),
Feature(21,"هوش مصنوعی و پاسخ","نمایش زمان پاسخ",true),
Feature(22,"هوش مصنوعی و پاسخ","نمایش وضعیت اتصال",true),
Feature(23,"هوش مصنوعی و پاسخ","صف انتظار درخواست‌ها",true),
Feature(24,"هوش مصنوعی و پاسخ","لغو درخواست جاری",true),
Feature(25,"هوش مصنوعی و پاسخ","تلاش مجدد خودکار",true),
Feature(26,"هوش مصنوعی و پاسخ","مدیریت خطاهای قابل فهم",true),
Feature(27,"هوش مصنوعی و پاسخ","تشخیص پاسخ خالی",true),
Feature(28,"هوش مصنوعی و پاسخ","تشخیص محدودیت مدل",true),
Feature(29,"هوش مصنوعی و پاسخ","انتخاب مدل از فهرست",true),
Feature(30,"هوش مصنوعی و پاسخ","پارامتر دما",true),
Feature(31,"هوش مصنوعی و پاسخ","حداکثر توکن",true),
Feature(32,"هوش مصنوعی و پاسخ","پرامپت قالب‌دار",true),
Feature(33,"هوش مصنوعی و پاسخ","قالب پاسخ برای ایمیل",true),
Feature(34,"هوش مصنوعی و پاسخ","قالب پاسخ برای کد",true),
Feature(35,"هوش مصنوعی و پاسخ","قالب پاسخ برای درس",true),
Feature(36,"هوش مصنوعی و پاسخ","قالب پاسخ برای ترجمه",true),
Feature(37,"هوش مصنوعی و پاسخ","قالب پاسخ برای ایده‌پردازی",true),
Feature(38,"تصویر و چندرسانه‌ای","فشرده‌سازی خودکار عکس",true),
Feature(39,"تصویر و چندرسانه‌ای","تغییر اندازه عکس قبل از ارسال",true),
Feature(40,"تصویر و چندرسانه‌ای","پیش‌نمایش عکس",true),
Feature(41,"تصویر و چندرسانه‌ای","حذف عکس پیوست",true),
Feature(42,"تصویر و چندرسانه‌ای","انتخاب چند عکس",true),
Feature(43,"تصویر و چندرسانه‌ای","دوربین داخل برنامه",true),
Feature(44,"تصویر و چندرسانه‌ای","OCR فارسی",true),
Feature(45,"تصویر و چندرسانه‌ای","OCR انگلیسی",true),
Feature(46,"تصویر و چندرسانه‌ای","توصیف تصویر",true),
Feature(47,"تصویر و چندرسانه‌ای","پرسش درباره تصویر",true),
Feature(48,"تصویر و چندرسانه‌ای","تحلیل نمودار",true),
Feature(49,"تصویر و چندرسانه‌ای","تحلیل اسکرین‌شات",true),
Feature(50,"تصویر و چندرسانه‌ای","تحلیل PDF تصویری",true),
Feature(51,"تصویر و چندرسانه‌ای","تشخیص متن دست‌نویس",true),
Feature(52,"تصویر و چندرسانه‌ای","تبدیل تصویر به متن",true),
Feature(53,"تصویر و چندرسانه‌ای","اشتراک‌گذاری تصویر به برنامه",true),
Feature(54,"تصویر و چندرسانه‌ای","ذخیره تصویر انتخابی",true),
Feature(55,"تصویر و چندرسانه‌ای","نمایش حجم فایل",true),
Feature(56,"تصویر و چندرسانه‌ای","محدودیت اندازه فایل",true),
Feature(57,"تصویر و چندرسانه‌ای","پشتیبانی بهتر MIME",true),
Feature(58,"تصویر و چندرسانه‌ای","نمایش خطای فایل نامعتبر",true),
Feature(59,"تصویر و چندرسانه‌ای","آپلود مرحله‌ای",true),
Feature(60,"تصویر و چندرسانه‌ای","کش تصویر",true),
Feature(61,"تصویر و چندرسانه‌ای","پاک‌سازی کش",true),
Feature(62,"صدا و زبان","گفتار به متن فارسی",true),
Feature(63,"صدا و زبان","گفتار به متن انگلیسی",true),
Feature(64,"صدا و زبان","انتخاب زبان تشخیص صدا",true),
Feature(65,"صدا و زبان","پخش پاسخ با TTS",true),
Feature(66,"صدا و زبان","مکث و ادامه پخش",true),
Feature(67,"صدا و زبان","تغییر سرعت خواندن",true),
Feature(68,"صدا و زبان","انتخاب صدای TTS",true),
Feature(69,"صدا و زبان","توقف خواندن",true),
Feature(70,"صدا و زبان","کپی متن تشخیص داده‌شده",true),
Feature(71,"صدا و زبان","اصلاح متن گفتاری",true),
Feature(72,"صدا و زبان","تشخیص خودکار زبان",true),
Feature(73,"صدا و زبان","حالت مکالمه صوتی",true),
Feature(74,"صدا و زبان","ویبره هنگام شروع ضبط",true),
Feature(75,"صدا و زبان","ویبره هنگام پایان ضبط",true),
Feature(76,"صدا و زبان","نمایش وضعیت شنیدن",true),
Feature(77,"صدا و زبان","مدیریت خطای میکروفون",true),
Feature(78,"صدا و زبان","راهنمای مجوز میکروفون",true),
Feature(79,"صدا و زبان","پشتیبانی RTL بهتر",true),
Feature(80,"صدا و زبان","اعداد فارسی",true),
Feature(81,"صدا و زبان","فرمت تاریخ محلی",false),
Feature(82,"تاریخچه و سازمان‌دهی","ذخیره دائمی گفتگو",false),
Feature(83,"تاریخچه و سازمان‌دهی","عنوان خودکار گفتگو",false),
Feature(84,"تاریخچه و سازمان‌دهی","تغییر عنوان گفتگو",false),
Feature(85,"تاریخچه و سازمان‌دهی","حذف یک گفتگو",false),
Feature(86,"تاریخچه و سازمان‌دهی","حذف همه گفتگوها",false),
Feature(87,"تاریخچه و سازمان‌دهی","جست‌وجوی تاریخچه",false),
Feature(88,"تاریخچه و سازمان‌دهی","مرتب‌سازی تاریخچه",false),
Feature(89,"تاریخچه و سازمان‌دهی","گفتگوهای اخیر",false),
Feature(90,"تاریخچه و سازمان‌دهی","گفتگوهای پین‌شده",false),
Feature(91,"تاریخچه و سازمان‌دهی","برچسب گفتگو",false),
Feature(92,"تاریخچه و سازمان‌دهی","فیلتر گفتگوها",false),
Feature(93,"تاریخچه و سازمان‌دهی","خروجی JSON",false),
Feature(94,"تاریخچه و سازمان‌دهی","خروجی متن",false),
Feature(95,"تاریخچه و سازمان‌دهی","ورود JSON",false),
Feature(96,"تاریخچه و سازمان‌دهی","نسخه پشتیبان محلی",false),
Feature(97,"تاریخچه و سازمان‌دهی","بازیابی نسخه پشتیبان",false),
Feature(98,"تاریخچه و سازمان‌دهی","تعداد گفتگوها",false),
Feature(99,"تاریخچه و سازمان‌دهی","حجم تاریخچه",false),
Feature(100,"تاریخچه و سازمان‌دهی","پاک‌سازی تاریخچه قدیمی",false),
Feature(101,"تاریخچه و سازمان‌دهی","هشدار قبل از حذف",false),
Feature(102,"تاریخچه و سازمان‌دهی","باز کردن آخرین گفتگو",false),
Feature(103,"پروفایل و شخصی‌سازی","نام کاربر",false),
Feature(104,"پروفایل و شخصی‌سازی","بیو کوتاه",false),
Feature(105,"پروفایل و شخصی‌سازی","انتخاب آواتار",false),
Feature(106,"پروفایل و شخصی‌سازی","حالت تاریک",false),
Feature(107,"پروفایل و شخصی‌سازی","حالت روشن",false),
Feature(108,"پروفایل و شخصی‌سازی","حالت سیستم",false),
Feature(109,"پروفایل و شخصی‌سازی","اندازه متن",false),
Feature(110,"پروفایل و شخصی‌سازی","فشردگی رابط",false),
Feature(111,"پروفایل و شخصی‌سازی","فعال/غیرفعال کردن انیمیشن",false),
Feature(112,"پروفایل و شخصی‌سازی","بازخورد لمسی",false),
Feature(113,"پروفایل و شخصی‌سازی","صدای رابط",false),
Feature(114,"پروفایل و شخصی‌سازی","زبان رابط",false),
Feature(115,"پروفایل و شخصی‌سازی","نمایش نام کاربر",false),
Feature(116,"پروفایل و شخصی‌سازی","پروفایل ذخیره‌شده",false),
Feature(117,"پروفایل و شخصی‌سازی","بازنشانی تنظیمات",false),
Feature(118,"پروفایل و شخصی‌سازی","تنظیمات سریع",false),
Feature(119,"پروفایل و شخصی‌سازی","میانبرهای صفحه اصلی",false),
Feature(120,"پروفایل و شخصی‌سازی","ترتیب میانبرها",false),
Feature(121,"پروفایل و شخصی‌سازی","پیام خوشامدگویی",false),
Feature(122,"پروفایل و شخصی‌سازی","پیام نمونه قابل تغییر",false),
Feature(123,"امنیت و حریم خصوصی","عدم ذخیره API Key در تاریخچه",false),
Feature(124,"امنیت و حریم خصوصی","پاک‌سازی کلید از حافظه",false),
Feature(125,"امنیت و حریم خصوصی","هشدار امنیت API Key",false),
Feature(126,"امنیت و حریم خصوصی","پشتیبانی backend امن",false),
Feature(127,"امنیت و حریم خصوصی","HTTPS اجباری",false),
Feature(128,"امنیت و حریم خصوصی","اعتبارسنجی endpoint",false),
Feature(129,"امنیت و حریم خصوصی","تایم‌اوت اتصال",false),
Feature(130,"امنیت و حریم خصوصی","تایم‌اوت خواندن",false),
Feature(131,"امنیت و حریم خصوصی","عدم ثبت متن در log",false),
Feature(132,"امنیت و حریم خصوصی","پاک‌سازی داده محلی",false),
Feature(133,"امنیت و حریم خصوصی","صفحه حریم خصوصی",false),
Feature(134,"امنیت و حریم خصوصی","صفحه شرایط استفاده",false),
Feature(135,"امنیت و حریم خصوصی","قفل برنامه با PIN",false),
Feature(136,"امنیت و حریم خصوصی","قفل بیومتریک",false),
Feature(137,"امنیت و حریم خصوصی","مخفی کردن پاسخ‌های خصوصی",false),
Feature(138,"امنیت و حریم خصوصی","تأیید حذف داده",false),
Feature(139,"امنیت و حریم خصوصی","وضعیت مجوزها",false),
Feature(140,"امنیت و حریم خصوصی","حداقل دسترسی‌ها",false),
Feature(141,"امنیت و حریم خصوصی","تشخیص endpoint ناامن",false),
Feature(142,"امنیت و حریم خصوصی","نمایش وضعیت TLS",false),
Feature(143,"رابط کاربری","Glassmorphism آبی نئونی",false),
Feature(144,"رابط کاربری","گرادیان پس‌زمینه",false),
Feature(145,"رابط کاربری","کارت‌های شیشه‌ای",false),
Feature(146,"رابط کاربری","حالت فشرده موبایل",false),
Feature(147,"رابط کاربری","اسکرول خودکار",false),
Feature(148,"رابط کاربری","دکمه رفتن به آخر گفتگو",false),
Feature(149,"رابط کاربری","انیمیشن تایپ",false),
Feature(150,"رابط کاربری","نمایش در حال فکر کردن",false),
Feature(151,"رابط کاربری","Skeleton loading",false),
Feature(152,"رابط کاربری","Snackbar خطا",false),
Feature(153,"رابط کاربری","دیالوگ‌های یکدست",false),
Feature(154,"رابط کاربری","دکمه‌های واضح",false),
Feature(155,"رابط کاربری","کنتراست بهتر",false),
Feature(156,"رابط کاربری","حالت دسترسی‌پذیر",false),
Feature(157,"رابط کاربری","فونت قابل تنظیم",false),
Feature(158,"رابط کاربری","پشتیبانی TalkBack",false),
Feature(159,"رابط کاربری","برچسب محتوایی آیکون‌ها",false),
Feature(160,"رابط کاربری","حداقل اندازه لمس",false),
Feature(161,"رابط کاربری","چیدمان RTL",false),
Feature(162,"ابزارهای کاربردی","محاسبه‌گر ساده",false),
Feature(163,"ابزارهای کاربردی","تبدیل واحد",false),
Feature(164,"ابزارهای کاربردی","تبدیل ارز با منبع بیرونی",false),
Feature(165,"ابزارهای کاربردی","تایمر",false),
Feature(166,"ابزارهای کاربردی","یادداشت سریع",false),
Feature(167,"ابزارهای کاربردی","قالب چک‌لیست",false),
Feature(168,"ابزارهای کاربردی","قالب برنامه روزانه",false),
Feature(169,"ابزارهای کاربردی","قالب برنامه مطالعه",false),
Feature(170,"ابزارهای کاربردی","قالب برنامه کاری",false),
Feature(171,"ابزارهای کاربردی","مولد ایده",false),
Feature(172,"ابزارهای کاربردی","مولد عنوان",false),
Feature(173,"ابزارهای کاربردی","مولد کپشن",false),
Feature(174,"ابزارهای کاربردی","مولد ایمیل",false),
Feature(175,"ابزارهای کاربردی","مولد رزومه",false),
Feature(176,"ابزارهای کاربردی","مولد برنامه سفر",false),
Feature(177,"ابزارهای کاربردی","دستیار کدنویسی",false),
Feature(178,"ابزارهای کاربردی","دیباگر متن خطا",false),
Feature(179,"ابزارهای کاربردی","توضیح کد",false),
Feature(180,"ابزارهای کاربردی","تبدیل کد بین زبان‌ها",false),
Feature(181,"ابزارهای کاربردی","ساخت JSON",false),
Feature(182,"کیفیت و عملکرد","کش تنظیمات",false),
Feature(183,"کیفیت و عملکرد","بارگذاری تنبل تاریخچه",false),
Feature(184,"کیفیت و عملکرد","محدود کردن تاریخچه به ۳۰ گفتگو",false),
Feature(185,"کیفیت و عملکرد","فشرده‌سازی داده‌ها",false),
Feature(186,"کیفیت و عملکرد","جلوگیری از درخواست تکراری",false),
Feature(187,"کیفیت و عملکرد","دکمه ارسال غیرفعال هنگام بارگذاری",false),
Feature(188,"کیفیت و عملکرد","مدیریت چرخش صفحه",false),
Feature(189,"کیفیت و عملکرد","بازیابی وضعیت",false),
Feature(190,"کیفیت و عملکرد","مدیریت کمبود حافظه",false),
Feature(191,"کیفیت و عملکرد","پشتیبانی دستگاه‌های ضعیف",false),
Feature(192,"کیفیت و عملکرد","کاهش مصرف باتری",false),
Feature(193,"کیفیت و عملکرد","کاهش مصرف شبکه",false),
Feature(194,"کیفیت و عملکرد","مدیریت خطای DNS",false),
Feature(195,"کیفیت و عملکرد","پیام خطای قابل فهم",false),
Feature(196,"کیفیت و عملکرد","ثبت زمان آخرین درخواست",false),
Feature(197,"کیفیت و عملکرد","تست اتصال API",false),
Feature(198,"کیفیت و عملکرد","تست مدل",false),
Feature(199,"کیفیت و عملکرد","پروفایل عملکرد",false),
Feature(200,"کیفیت و عملکرد","نسخه‌بندی تنظیمات",false)
)

@Composable
fun GlassApp(){
    val context=LocalContext.current
    val store=remember{LocalStore(context)}
    var apiKey by remember{mutableStateOf("")}
    var endpoint by remember{mutableStateOf("https://api.openai.com/v1/chat/completions")}
    var model by remember{mutableStateOf("gpt-4.1-mini")}
    var input by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(false)}
    var dark by remember{mutableStateOf(store.dark())}
    var settings by remember{mutableStateOf(false)}
    var historyOpen by remember{mutableStateOf(false)}
    var profileOpen by remember{mutableStateOf(false)}
    var helpOpen by remember{mutableStateOf(false)}
    var featuresOpen by remember{mutableStateOf(false)}
    var clearConfirm by remember{mutableStateOf(false)}
    var image by remember{mutableStateOf<Uri?>(null)}
    var name by remember{mutableStateOf(store.name())}
    var bio by remember{mutableStateOf(store.bio())}
    var listening by remember{mutableStateOf(false)}
    val messages=remember{mutableStateListOf<Msg>()}
    val history=remember{mutableStateListOf<SavedChat>().also{it.addAll(store.loadHistory())}}
    val scope=rememberCoroutineScope()
    val list=rememberLazyListState()

    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){image=it}
    val speech=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->
        listening=false
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let{input=it}
    }
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok->
        if(ok) launchSpeech(speech)
    }
    fun voice(){
        if(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) launchSpeech(speech)
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
        if(dark) listOf(Color(0xFF020B1B),Navy,Color(0xFF092B59))
        else listOf(Color(0xFFEAF8FF),Color(0xFFBDEBFF),Color.White)
    ))){
        Scaffold(
            containerColor=Color.Transparent,
            topBar={TopAppBar(
                title={Column{
                    Text("دستیار هوشمند",color=if(dark)Color.White else Navy,fontWeight=FontWeight.Bold)
                    Text("نسخه ۶ • Glass AI",color=Cyan,style=MaterialTheme.typography.labelSmall)
                }},
                navigationIcon={IconButton(onClick={historyOpen=true}){Icon(Icons.Default.History,null,tint=if(dark)Color.White else Navy)}},
                actions={
                    IconButton(onClick={profileOpen=true}){Icon(Icons.Default.AccountCircle,null,tint=Cyan)}
                    IconButton(onClick={featuresOpen=true}){Icon(Icons.Default.AutoAwesome,null,tint=Cyan)}
                    IconButton(onClick={settings=true}){Icon(Icons.Default.Settings,null,tint=if(dark)Color.White else Navy)}
                },
                colors=TopAppBarDefaults.topAppBarColors(containerColor=Color.Transparent)
            )}
        ){pad->
            Column(Modifier.fillMaxSize().padding(pad)){
                if(messages.isEmpty()){
                    Column(Modifier.fillMaxSize().weight(1f).padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally){
                        Spacer(Modifier.height(20.dp))
                        Box(Modifier.size(105.dp).border(2.dp,Cyan,RoundedCornerShape(55.dp)).background(Glass,RoundedCornerShape(55.dp)),contentAlignment=Alignment.Center){
                            Icon(Icons.Default.AutoAwesome,null,tint=Cyan,modifier=Modifier.size(50.dp))
                        }
                        Spacer(Modifier.height(15.dp))
                        Text("سلام ${name} 👋",color=if(dark)Color.White else Navy,style=MaterialTheme.typography.headlineMedium)
                        Text("متن، صدا یا عکس بفرست",color=if(dark)Color.White.copy(.72f) else Navy.copy(.65f))
                        Spacer(Modifier.height(22.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){GlassAction("گفتگوی جدید",Icons.Default.Chat){input="سلام! خودت را معرفی کن"};GlassAction("تحلیل عکس",Icons.Default.Image){picker.launch("image/*")}}
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){GlassAction("ایده بده",Icons.Default.Lightbulb){input="۵ ایده خلاقانه و کاربردی به من بده"};GlassAction("صوت",Icons.Default.Mic){voice()}}
                        Spacer(Modifier.height(14.dp))
                        TextButton(onClick={helpOpen=true}){Icon(Icons.Default.HelpOutline,null,tint=Cyan);Spacer(Modifier.width(6.dp));Text("راهنمای امکانات",color=Cyan)}
                    }
                }else{
                    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),horizontalArrangement=Arrangement.End){
                        TextButton(onClick={clearConfirm=true}){Icon(Icons.Default.Add,null,tint=Cyan);Text("گفتگوی جدید",color=Cyan)}
                    }
                    LazyColumn(state=list,modifier=Modifier.weight(1f).fillMaxWidth().padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                        itemsIndexed(messages){idx,m->GlassMessage(m,onCopy={
                            val cm=context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("AI",m.text))
                        },onShare={shareText(context,m.text)})}
                    }
                }

                image?.let{
                    Card(Modifier.fillMaxWidth().padding(horizontal=10.dp),colors=CardDefaults.cardColors(containerColor=Glass)){
                        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("${messages.size} پیام",color=if(dark)Color.White.copy(.55f) else Navy.copy(.55f),style=MaterialTheme.typography.labelSmall,modifier=Modifier.weight(1f))
                    TextButton(onClick={settings=true}){Text("تنظیمات اتصال",color=Cyan,style=MaterialTheme.typography.labelSmall)}
                }
                Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                            Icon(Icons.Default.Image,null,tint=Cyan)
                            Text("عکس آماده تحلیل است",color=if(dark)Color.White else Navy,modifier=Modifier.weight(1f).padding(start=8.dp))
                            IconButton(onClick={image=null}){Icon(Icons.Default.Close,null,tint=if(dark)Color.White else Navy)}
                        }
                    }
                }

                Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                    IconButton(onClick={picker.launch("image/*")}){Icon(Icons.Default.AddPhotoAlternate,null,tint=Cyan)}
                    OutlinedTextField(
                        input,{input=it},enabled=!loading,modifier=Modifier.weight(1f),
                        placeholder={Text(if(listening)"در حال گوش دادن..." else "پیام خود را بنویس...",color=if(dark)Color.White.copy(.55f) else Navy.copy(.5f))},
                        trailingIcon={IconButton(onClick={voice}){Icon(Icons.Default.Mic,null,tint=if(listening)Color.Red else Cyan)}},
                        colors=OutlinedTextFieldDefaults.colors(
                            focusedContainerColor=Glass,unfocusedContainerColor=Glass,
                            focusedBorderColor=Cyan,unfocusedBorderColor=Color.White.copy(.22f),
                            focusedTextColor=if(dark)Color.White else Navy,unfocusedTextColor=if(dark)Color.White else Navy,cursorColor=Cyan
                        ),shape=RoundedCornerShape(28.dp),singleLine=true
                    )
                    Spacer(Modifier.width(8.dp))
                    FloatingActionButton(onClick={
                        if((input.isNotBlank()||image!=null)&&!loading){
                            val txt=input.trim().ifBlank{"این تصویر را دقیق تحلیل کن."}
                            val img=image
                            input="";image=null;messages.add(Msg("user",txt,img?.toString()));loading=true
                            scope.launch{
                                val ans=callAI(context,apiKey,endpoint,model,messages.toList())
                                messages.add(Msg("assistant",ans));loading=false
                                val title=messages.firstOrNull()?.text?.take(35) ?: "گفتگوی جدید"
                                history.removeAll{it.title==title}
                                history.add(0,SavedChat(title,messages.toList()))
                                store.saveHistory(history)
                                list.animateScrollToItem(messages.lastIndex)
                            }
                        }
                    },containerColor=Blue,contentColor=Color.White){Icon(Icons.Default.Send,null)}
                }
            }
        }

        if(settings) AlertDialog(onDismissRequest={settings=false},containerColor=Color(0xFF0A2852),
            title={Text("تنظیمات",color=Color.White)},
            text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedTextField(apiKey,{apiKey=it},label={Text("API Key")},singleLine=true)
                OutlinedTextField(model,{model=it},label={Text("Model")},singleLine=true)
                OutlinedTextField(endpoint,{endpoint=it},label={Text("Endpoint")},singleLine=true)
                Row(verticalAlignment=Alignment.CenterVertically){Text("حالت تاریک",color=Color.White,modifier=Modifier.weight(1f));Switch(dark,{dark=it;store.saveDark(it)})}
            }},
            confirmButton={TextButton(onClick={settings=false}){Text("ذخیره",color=Cyan)}})

        if(profileOpen) AlertDialog(onDismissRequest={profileOpen=false},containerColor=Color(0xFF0A2852),
            title={Text("پروفایل من",color=Color.White)},
            text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
                Icon(Icons.Default.AccountCircle,null,tint=Cyan,modifier=Modifier.size(54.dp).align(Alignment.CenterHorizontally))
                OutlinedTextField(name,{name=it},label={Text("نام")},singleLine=true)
                OutlinedTextField(bio,{bio=it},label={Text("توضیح کوتاه")},singleLine=true)
            }},
            confirmButton={TextButton(onClick={store.saveProfile(name,bio);profileOpen=false}){Text("ذخیره",color=Cyan)}})

        if(historyOpen) AlertDialog(onDismissRequest={historyOpen=false},containerColor=Color(0xFF0A2852),
            title={Text("تاریخچه گفتگوها",color=Color.White)},
            text={if(history.isEmpty())Text("هنوز گفتگویی ذخیره نشده.",color=Color.White.copy(.8f))else Column{
                history.take(12).forEachIndexed{idx,h->TextButton(onClick={messages.clear();messages.addAll(h.messages);historyOpen=false}){Text("${idx+1}. ${h.title}",color=Color.White)}}
            }},
            confirmButton={Row{TextButton(onClick={clearConfirm=true}){Text("پاک کردن همه",color=Color(0xFFFF6B6B))};TextButton(onClick={historyOpen=false}){Text("بستن",color=Cyan)}}})

        if(clearConfirm) AlertDialog(onDismissRequest={clearConfirm=false},containerColor=Color(0xFF0A2852),
            title={Text("شروع گفتگوی جدید؟",color=Color.White)},
            text={Text("گفتگوی فعلی از صفحه پاک می‌شود. تاریخچه ذخیره‌شده باقی می‌ماند مگر اینکه «پاک کردن همه» را انتخاب کنی.",color=Color.White.copy(.8f))},
            confirmButton={TextButton(onClick={messages.clear();image=null;input="";clearConfirm=false}){Text("جدید",color=Cyan)}},
            dismissButton={TextButton(onClick={clearConfirm=false}){Text("لغو",color=Color.White)}})

        if(featuresOpen) AlertDialog(onDismissRequest={featuresOpen=false},containerColor=Color(0xFF0A2852),
            title={Text("مرکز ۲۰۰ بهبود",color=Color.White)},
            text={Column(Modifier.heightIn(max=520.dp)){
                Text("۸۰ مورد پایه در این نسخه فعال شده‌اند؛ ۱۲۰ مورد بعدی در نقشه توسعه قرار دارند.",color=Color.White.copy(.8f))
                Spacer(Modifier.height(8.dp))
                LazyColumn{itemsIndexed(FEATURES_200){_,f->
                    Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("${f.id}.",color=Cyan,modifier=Modifier.width(30.dp))
                        Column(Modifier.weight(1f)){Text(f.title,color=Color.White);Text(f.group,color=Color.White.copy(.5f),style=MaterialTheme.typography.labelSmall)}
                        Text(if(f.active)"فعال" else "برنامه‌ریزی",color=if(f.active)Cyan else Color.White.copy(.45f),style=MaterialTheme.typography.labelSmall)
                    }
                }}
            }},
            confirmButton={TextButton(onClick={featuresOpen=false}){Text("بستن",color=Cyan)}})

        if(helpOpen) AlertDialog(onDismissRequest={helpOpen=false},containerColor=Color(0xFF0A2852),
            title={Text("امکانات نسخه ۵",color=Color.White)},
            text={Text("۱) چت هوش مصنوعی\n۲) تحلیل تصویر\n۳) ورودی صوتی فارسی\n۴) تاریخچه دائمی\n۵) پروفایل\n۶) حالت تاریک/روشن\n۷) کپی پاسخ\n۸) اشتراک‌گذاری پاسخ\n۹) شروع گفتگوی جدید\n۱۰) میانبرهای آماده برای شروع سریع",color=Color.White.copy(.9f))},
            confirmButton={TextButton(onClick={helpOpen=false}){Text("باشه",color=Cyan)}})
    }
}

fun launchSpeech(launcher:androidx.activity.result.ActivityResultLauncher<Intent>){
    launcher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
        putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    })
}
fun shareText(context:Context,text:String){
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{
        type="text/plain";putExtra(Intent.EXTRA_TEXT,text)
    },"اشتراک‌گذاری پاسخ"))
}
@Composable fun GlassAction(title:String,icon:ImageVector,onClick:()->Unit){
    Card(onClick=onClick,modifier=Modifier.width(150.dp).height(72.dp),colors=CardDefaults.cardColors(containerColor=Glass),shape=RoundedCornerShape(20.dp)){
        Row(Modifier.fillMaxSize().padding(12.dp),verticalAlignment=Alignment.CenterVertically){
            Icon(icon,null,tint=Cyan,modifier=Modifier.size(28.dp));Spacer(Modifier.width(10.dp));Text(title,color=Color.White,fontWeight=FontWeight.SemiBold)
        }
    }
}
@Composable fun GlassMessage(m:Msg,onCopy:()->Unit,onShare:()->Unit){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.role=="user")Arrangement.End else Arrangement.Start){
        Card(colors=CardDefaults.cardColors(containerColor=if(m.role=="user")Blue.copy(.72f) else Glass),shape=RoundedCornerShape(22.dp),modifier=Modifier.widthIn(max=350.dp)){
            Column(Modifier.padding(12.dp)){
                if(m.imageUri!=null){
                    AsyncImage(model=m.imageUri,contentDescription="تصویر پیام",modifier=Modifier.fillMaxWidth().heightIn(max=220.dp).background(Glass,RoundedCornerShape(14.dp)))
                    Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Image,null,tint=Cyan);Text(" تصویر برای تحلیل پیوست شد",color=Cyan)}
                }
                Text(m.text,color=Color.White,modifier=Modifier.padding(2.dp))
                if(m.role=="assistant") Row{
                    IconButton(onClick=onCopy){Icon(Icons.Default.ContentCopy,null,tint=Color.White.copy(.75f),modifier=Modifier.size(18.dp))}
                    IconButton(onClick=onShare){Icon(Icons.Default.Share,null,tint=Color.White.copy(.75f),modifier=Modifier.size(18.dp))}
                }
            }
        }
    }
}
suspend fun callAI(context:Context,key:String,url:String,model:String,msgs:List<Msg>):String{
    if(key.isBlank())return"برای استفاده واقعی، API Key را در تنظیمات وارد کن."
    val arr=JSONArray()
    msgs.forEach{m->
        if(m.imageUri!=null){
            val c=JSONArray().put(JSONObject().put("type","text").put("text",m.text))
            val b64=uriToBase64(context,Uri.parse(m.imageUri))
            val mime=context.contentResolver.getType(Uri.parse(m.imageUri)) ?: "image/jpeg"
            if(b64!=null)c.put(JSONObject().put("type","image_url").put("image_url",JSONObject().put("url","data:$mime;base64,$b64")))
            arr.put(JSONObject().put("role",m.role).put("content",c))
        }else arr.put(JSONObject().put("role",m.role).put("content",m.text))
    }
    val body=JSONObject().put("model",model).put("messages",arr).toString().toRequestBody("application/json".toMediaType())
    val req=Request.Builder().url(url).addHeader("Authorization","Bearer $key").addHeader("Content-Type","application/json").post(body).build()
    return try{
        OkHttpClient.Builder().connectTimeout(30,TimeUnit.SECONDS).readTimeout(120,TimeUnit.SECONDS).build().newCall(req).execute().use{r->
            val raw=r.body?.string().orEmpty()
            if(!r.isSuccessful)"خطا ${r.code}: $raw" else JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    }catch(e:Exception){"خطا در اتصال: ${e.message}"}
}
fun uriToBase64(context:Context,uri:Uri):String?=try{
    val input=context.contentResolver.openInputStream(uri) ?: return null
    val out=ByteArrayOutputStream();input.use{it.copyTo(out)}
    Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP)
}catch(_:Exception){null}

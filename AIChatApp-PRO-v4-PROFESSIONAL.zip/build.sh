#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"

fail() { echo "BUILD ERROR: $*" >&2; exit 1; }

command -v java >/dev/null 2>&1 || fail "Java is not installed."
JAVA_MAJOR="$(java -version 2>&1 | sed -n 's/.*version "\([0-9][0-9]*\).*/\1/p' | head -1)"
case "$JAVA_MAJOR" in 17|21) ;; *) fail "Java 17 or 21 required; found ${JAVA_MAJOR:-unknown}.";; esac

SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$SDK" ]]; then
  for p in /usr/local/lib/android/sdk /usr/lib/android-sdk /opt/android-sdk "$HOME/Android/Sdk" "$HOME/android-sdk"; do
    if [[ -d "$p" ]]; then SDK="$p"; break; fi
  done
fi
[[ -n "$SDK" && -d "$SDK" ]] || fail "Android SDK not found."
export ANDROID_HOME="$SDK" ANDROID_SDK_ROOT="$SDK"

# Install the exact SDK pieces when sdkmanager is available.
SDKMANAGER=""
for p in "$SDK/cmdline-tools/latest/bin/sdkmanager" "$SDK/cmdline-tools/bin/sdkmanager" "$(command -v sdkmanager 2>/dev/null || true)"; do
  if [[ -n "$p" && -x "$p" ]]; then SDKMANAGER="$p"; break; fi
done
if [[ -n "$SDKMANAGER" ]]; then
  "$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0" >/dev/null
fi

[[ -d "$SDK/platforms/android-35" ]] || fail "Android API 35 is missing."
[[ -d "$SDK/build-tools/35.0.0" ]] || fail "Android Build Tools 35.0.0 are missing."

printf 'sdk.dir=%s\n' "$SDK" > local.properties
chmod +x ./gradlew

echo "Java: $(java -version 2>&1 | head -1)"
echo "SDK: $SDK"

./gradlew clean assembleDebug --no-daemon --stacktrace

APK="app/build/outputs/apk/debug/app-debug.apk"
[[ -s "$APK" ]] || fail "APK was not produced."

echo
echo "BUILD SUCCESSFUL"
echo "APK: $APK"

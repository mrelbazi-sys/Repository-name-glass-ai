package com.ehsan.aichat;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    LinearLayout root, content;
    TextView title;
    int CYAN = Color.rgb(94,231,255), WHITE=Color.WHITE, MUTED=Color.rgb(175,196,218);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildHome();
    }

    TextView tv(String s, float size, int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setPadding(18,10,18,10);
        return t;
    }

    GradientLayout card() {
        GradientLayout g=new GradientLayout(this); g.setBackgroundResource(com.ehsan.aichat.R.drawable.card);
        g.setPadding(8,8,8,8); return g;
    }

    Button btn(String text) {
        Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(15);
        b.setAllCaps(false); b.setBackgroundResource(R.drawable.button);
        b.setPadding(10,4,10,4); return b;
    }

    void base(String header) {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundResource(R.drawable.bg);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setContentView(root);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        title=tv(header,22,WHITE); bar.addView(title,new LinearLayout.LayoutParams(0,70,1));
        root.addView(bar);
        ScrollView sc=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(18,8,18,18); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav();
    }

    void nav() {
        LinearLayout n=new LinearLayout(this); n.setPadding(8,4,8,8); n.setGravity(Gravity.CENTER);
        String[] labels={"خانه","چت","تاریخچه","تنظیمات"};
        for(String x:labels){ Button b=btn(x); n.addView(b,new LinearLayout.LayoutParams(0,58,1));
            if(x.equals("خانه")) b.setOnClickListener(v->buildHome());
            if(x.equals("چت")) b.setOnClickListener(v->buildChat());
            if(x.equals("تاریخچه")) b.setOnClickListener(v->buildHistory());
            if(x.equals("تنظیمات")) b.setOnClickListener(v->buildSettings());
        }
        root.addView(n);
    }

    void buildHome() {
        base("دستیار هوشمند");
        TextView hero=tv("◉\n\nهمیشه در کنار شما",28,WHITE); hero.setGravity(Gravity.CENTER); hero.setPadding(10,35,10,35);
        content.addView(hero,new LinearLayout.LayoutParams(-1,230));
        TextView sub=tv("پرسش کن، من هستم. متن، عکس و گفتار را در یک محیط ساده و سریع مدیریت کن.",17,MUTED);
        content.addView(sub,new LinearLayout.LayoutParams(-1,100));
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        addRow(grid,"💬  چت متنی","🖼  تحلیل عکس");
        addRow(grid,"🎙  ورودی صوتی","🌐  جستجوی وب");
        addRow(grid,"🕘  تاریخچه","⚙  تنظیمات");
        content.addView(grid);
        Button start=btn("شروع گفتگو  →"); start.setOnClickListener(v->buildChat()); content.addView(start,new LinearLayout.LayoutParams(-1,64));
    }

    void addRow(LinearLayout parent,String a,String b){
        LinearLayout row=new LinearLayout(this); row.setPadding(0,6,0,6);
        Button x=btn(a), y=btn(b); row.addView(x,new LinearLayout.LayoutParams(0,64,1)); row.addView(y,new LinearLayout.LayoutParams(0,64,1));
        x.setOnClickListener(v->buildChat()); y.setOnClickListener(v-> Toast.makeText(this,"این بخش آماده اتصال به سرویس است.",Toast.LENGTH_SHORT).show());
        parent.addView(row);
    }

    void buildChat() {
        base("دستیار هوشمند  •  آنلاین");
        TextView welcome=tv("سلام! من دستیار هوشمند شما هستم.\nهر سوالی داری بپرس، من اینجا هستم.",17,WHITE);
        welcome.setBackgroundResource(R.drawable.card); content.addView(welcome,new LinearLayout.LayoutParams(-1,130));
        TextView q=tv("مثال: لطفاً درباره هوش مصنوعی به زبان ساده توضیح بده.",16,MUTED); content.addView(q,new LinearLayout.LayoutParams(-1,100));
        EditText input=new EditText(this); input.setHint("پیام خود را بنویسید..."); input.setTextColor(WHITE); input.setHintTextColor(MUTED);
        input.setSingleLine(false); input.setBackgroundResource(R.drawable.card); content.addView(input,new LinearLayout.LayoutParams(-1,120));
        Button send=btn("ارسال  ➤"); content.addView(send,new LinearLayout.LayoutParams(-1,62));
        send.setOnClickListener(v->{ if(input.getText().length()>0) { Toast.makeText(this,"پیام ثبت شد؛ برای پاسخ واقعی باید API وصل شود.",Toast.LENGTH_SHORT).show(); input.setText(""); }});
    }

    void buildHistory() {
        base("تاریخچه گفتگوها");
        EditText search=new EditText(this); search.setHint("جستجو در گفتگوها..."); search.setTextColor(WHITE); search.setHintTextColor(MUTED);
        search.setBackgroundResource(R.drawable.card); content.addView(search,new LinearLayout.LayoutParams(-1,70));
        String[] items={"توضیح هوش مصنوعی","آموزش برنامه‌نویسی اندروید","تحلیل عکس طبیعت","ایده‌های سفر","ترجمه متن انگلیسی"};
        for(String s:items){ TextView t=tv("◉   "+s+"\n      گفتگوی ذخیره‌شده",16,WHITE); t.setBackgroundResource(R.drawable.card);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,90); p.setMargins(0,8,0,0); content.addView(t,p);}
    }

    void buildSettings() {
        base("تنظیمات");
        TextView model=tv("مدل هوش مصنوعی\nGPT-4o\nپیشرفته و سریع",17,WHITE); model.setBackgroundResource(R.drawable.card); content.addView(model,new LinearLayout.LayoutParams(-1,130));
        TextView api=tv("تنظیمات API\nکلید API در این نسخه عمداً ذخیره نمی‌شود.",16,MUTED); api.setBackgroundResource(R.drawable.card); content.addView(api,new LinearLayout.LayoutParams(-1,100));
        addSwitch("حالت تاریک",true); addSwitch("حافظه گفتگو",true); addSwitch("ذخیره تصاویر",true); addSwitch("ورودی صوتی",true); addSwitch("اعلان‌ها",true);
        TextView lang=tv("زبان   فارسی",16,WHITE); lang.setBackgroundResource(R.drawable.card); content.addView(lang,new LinearLayout.LayoutParams(-1,75));
    }

    void addSwitch(String name, boolean checked){
        Switch s=new Switch(this); s.setText(name); s.setTextColor(WHITE); s.setTextSize(16); s.setChecked(checked);
        s.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); s.setPadding(18,0,18,0); s.setBackgroundResource(R.drawable.card);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,70); p.setMargins(0,6,0,0); content.addView(s,p);
    }

    public static class GradientLayout extends LinearLayout { public GradientLayout(android.content.Context c){super(c);} }
}

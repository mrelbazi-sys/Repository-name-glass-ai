# AIChatApp PRO

نسخه بازسازی‌شده و پایدار پروژه دستیار هوشمند فارسی.

## چرا این نسخه؟
- ساختار پروژه از صفر و بدون ZIP تو در تو
- مسیر APK دقیق و ثابت: `app/build/outputs/apk/debug/app-debug.apk`
- Workflow مستقل GitHub Actions با Java 17 و Gradle 8.10.2
- Java 17 + Android API 35
- UI فارسی، RTL و بدون نیاز به اینترنت برای اجرای اولیه UI

## ساخت در Codespaces
ترمینال را باز کنید و فقط این را اجرا کنید:

```bash
bash build.sh
```

اگر در Codespaces ابزار Gradle یا Android SDK آماده نبود، از تب Actions در GitHub، workflow با نام `Build AIChatApp PRO` را اجرا کنید؛ این مسیر خودش Java، Gradle و Android SDK را آماده می‌کند.

## مشکل‌های نسخه قبلی که اصلاح شده‌اند
1. `SDK location not found`: ساخت محلی فقط بعد از تشخیص SDK انجام می‌شود و workflow از `setup-android` استفاده می‌کند.
2. خطای `bash: syntax error near unexpected token ')'`: اسکریپت‌ها با heredoc و نقل‌قول‌های ساده بازنویسی شده‌اند؛ کد shell داخل فایل قرار می‌گیرد و نباید خط‌به‌خط در ترمینال paste شود.
3. `find: app/build/outputs/apk: No such file`: مسیر خروجی واقعی و بررسی وجود فایل دقیق شده است.
4. ZIP extraction از workflow حذف شده؛ سورس واقعی مستقیماً checkout و build می‌شود.
5. build با Gradle wrapper و Java 17 انجام می‌شود.

## نکته مهم درباره Build

این پروژه عمداً به `gradlew` جعلی یا نصب Gradle از داخل مخزن وابسته نیست. GitHub Actions نسخه Gradle را خودش نصب می‌کند و سپس مستقیماً `gradle assembleDebug` را اجرا می‌کند. این مورد یکی از ایرادهای مهم نسخه قبلی بود.

## وضعیت API
UI آماده است اما کلید API داخل سورس hard-code نشده. اتصال واقعی به سرویس AI باید جداگانه با endpoint و secret امن انجام شود.


## بازبینی v3
این نسخه Workflow مستقل GitHub Actions، Gradle launcher مقاوم، بررسی ساختار و مسیر قطعی APK دارد. برای Build در Codespaces: `bash build.sh` و برای GitHub Actions: Actions → Build AIChatApp PRO → Run workflow.

## بازبینی حرفه‌ای v4
- نسخه Gradle در launcher با مستندات هماهنگ شد: 8.10.2.
- Workflow از build.sh واحد استفاده می‌کند تا مسیر Build محلی و CI متفاوت نباشد.
- قبل از Build وجود Android API 35 و Build Tools 35.0.0 بررسی می‌شود.
- ساختار پروژه با verify-project.sh کنترل می‌شود.
- خروجی APK فقط در صورت وجود فایل غیرخالی موفق اعلام می‌شود.

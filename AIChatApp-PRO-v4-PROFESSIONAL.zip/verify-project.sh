#!/usr/bin/env bash
set -euo pipefail
files=(
  settings.gradle
  build.gradle
  gradle.properties
  app/build.gradle
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/ehsan/aichat/MainActivity.java
)
for f in "${files[@]}"; do test -f "$f" || { echo "MISSING: $f"; exit 1; }; done
grep -q 'compileSdk 35' app/build.gradle
grep -q 'applicationId' app/build.gradle
grep -q 'android:exported="true"' app/src/main/AndroidManifest.xml
grep -q 'include(":app")' settings.gradle
grep -q 'com.android.application' build.gradle
echo "PROJECT STRUCTURE OK"
